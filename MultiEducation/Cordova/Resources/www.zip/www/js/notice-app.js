// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
angular.module('fsc-www', ['ionic', 'fsc-www.helper'])


  .config(function ($stateProvider, $urlRouterProvider, wwwHelperProvider) {
    $stateProvider
      .state('main', {
        abstract: true,
        templateUrl: "views/notice/tabs.html"
      })
      .state('main.os_notice', {
        url: "/os/notice",
        params: {
          noticeScope: "os",
          title: "学校新闻"
        },
        views: {
          'tab-os': {
            templateUrl: "views/notice/list.html",
            controller: 'NoticeCtrl'
          }
        }
      })
      .state('os_notice_detail', {
        url: "/os/notice/:id",
        params: {
          noticeScope: "os",
          title: "学校新闻"
        },
        templateUrl: "views/notice/detail.html",
        controller: 'NoticeDetailCtrl'
        // views: {
        //   'tab-os': {
        //     templateUrl: "views/notice/detail.html",
        //     controller: 'NoticeDetailCtrl'
        //   }
        // }
      })
      .state('main.el_notice', {
        url: "/el/notice",
        params: {
          noticeScope: "el",
          title: "平台新闻"
        },
        views: {
          'tab-el': {
            templateUrl: "views/notice/list.html",
            controller: 'NoticeCtrl'
          }
        }
      })
      .state('el_notice_detail', {
        // params: {
        //   noticeScope: "el",
        //   title: "平台新闻"
        // },
        url: "/el/notice/:id",
        templateUrl: "views/notice/detail.html",
        controller: 'NoticeDetailCtrl'
        // views: {
        //   'tab-el': {
        //     templateUrl: "views/notice/detail.html",
        //     controller: 'NoticeDetailCtrl'
        //   }
        // }
      });

    $urlRouterProvider.otherwise("/os/notice");
    wwwHelperProvider.config();

  })

  .run(function (utils) {
    utils.run();

      window.back = function () {
          value.close.execute({});
      };



  })
