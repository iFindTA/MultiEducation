// Generated on Mon Aug 10 2015 12:22:54 GMT+0800 (中国标准时间) using generator-ngstone 0.2.8
'use strict';

// # Globbing
// for performance reasons we're only matching one level down:
// 'test/spec/{,*/}*.js'
// use this if you want to recursively match all subfolders:
// 'test/spec/**/*.js'
var path = require('path');

module.exports = function (grunt) {

    // Load grunt tasks automatically
    require('load-grunt-tasks')(grunt);

    // Time how long tasks take. Can help when optimizing build times
    require('time-grunt')(grunt);

    // Configurable paths for the application
    var appConfig = {
        projectName: 'www',
        app: '',
        dist: 'dist'
    };

    // Define the configuration for all the tasks
    grunt.initConfig({

        // Project settings
        yeoman: appConfig,
        //清除文件
        clean: {
            dist: {
                files: [
                    {
                        dot: true,
                        src: [
                            '.tmp',
                            'dist/{,*/}*',
                            '!dist/.git*'
                        ]
                    }
                ]
            },
            server: '.tmp'
        },

        //打包模板
        ngtemplates: {
            dist: {
                cwd: '<%= yeoman.app %>',
                src: [
                    'views/**/*.html'//这里的./很重要，必须和指令里的templateUrl等一致，否则应用运行时，模板无法加载
                ],
                dest: '.tmp/js/ngtemplates.js',
                options: {
                    module: 'angularApp',
                    prefix: '/',
                    htmlmin: {
                        collapseBooleanAttributes: true,
                        collapseWhitespace: true,
                        removeAttributeQuotes: false,//必须为false，否则usemin的正则无法匹配
                        removeComments: true, // Only if you don't use comment directives!
                        removeEmptyAttributes: true,
                        removeRedundantAttributes: false, //removing this as it can removes properties that can be used when styling
                        removeScriptTypeAttributes: true,
                        removeStyleLinkTypeAttributes: true
                    }
                }
            }
        },

        // Reads HTML for usemin blocks to enable smart builds that automatically
        // concat, minify and revision files. Creates configurations in memory so
        // additional tasks can operate on them
        useminPrepare: {
            html: '*.html',
            options: {
                dest: 'dist',
                flow: {
                    html: {
                        steps: {
                            js: ['concat', 'uglifyjs'],
                            css: ['cssmin']
                        },
                        post: {}
                    }
                }
            }
        },

        // Make sure code styles are up to par and there are no obvious mistakes
        jshint: {
            options: {
                jshintrc: '.jshintrc',
                reporter: require('jshint-stylish')
            },
            all: {
                src: [
                    'Gruntfile.js',
                    'js/**/*.js'
                ]
            },
            test: {
                options: {
                    jshintrc: 'test/.jshintrc'
                },
                src: ['test/spec/{,*/}*.js']
            }
        },

        // Renames files for browser caching purposes
        filerev: {
            dist: {
                src: [
                    'dist/js/{,*/}*.js',
                    'dist/css/{,*/}*.css'
                ]
            }
        },



        // Performs rewrites based on filerev and the useminPrepare configuration
        usemin: {
            html: ['dist/{,*/}*.html', 'dist/js/scripts*.js'],//后面这一项是给打包好的模板里的图片等加后缀的
            css: ['dist/css/{,*/}*.css'],
            options: {
                assetsDirs: ['dist', 'dist/images']
            }
        },

        htmlmin: {
            dist: {
                options: {
                    collapseWhitespace: true,
                    conservativeCollapse: true,
                    collapseBooleanAttributes: true,
                    removeCommentsFromCDATA: true,
                    removeOptionalTags: true
                },
                files: [
                    {
                        expand: true,
                        cwd: 'dist',
                        src: ['*.html','views/**/*.html'],
                        dest: 'dist'
                    }
                ]
            }
        },

        // ng-annotate tries to make the code safe for minification automatically
        // by using the Angular long form for dependency injection.
        ngAnnotate: {
            app: {
                files: [
                    {
                        expand: true,
                        cwd: 'js',
                        src: ['**/*.js'],
                        dest: '.tmp/app/js'
                    }
                ]
            }
        },

        concat: {//后期添加，将打包好了模板js，合并到之前的js里，由于useminPrepare通过读取index.html的注释生成concat的列表，无法将此模板文件打包进去，所以只能二次合并
//            ngtemplates: {
//                src: ['.tmp/concat/js/app.js', '.tmp/js/ngtemplates.js'],
//                dest: '.tmp/concat/js/app.js'
//            }
        },
        uglify: {
            generated: {
                files: [
                    {
                        expand:true,
                        dest: 'dist/js',
                        cwd:'.tmp/concat/js',//js目录下
                        src: [ '**/*.js' ]
                    }
                ]
            }
        },
        // Copies remaining files to places other tasks can use
        copy: {
            dist: {
                files: [
                    {
                        expand: true,
                        dot: true,
                        cwd: '<%= yeoman.app %>',
                        dest: 'dist',
                        src: [
                            '*.{ico,png,txt}',
                            '*.html',
                            '*.json',
                            'img/**/*.*',//imagesmin注释掉后，images目录不复制了
                            'views/**/*.html',
                            'lib/**/*.*'
                        ]
                    }
                    //more copies
                ]
            },
            styles: {
                expand: true,
                cwd: 'css',
                dest: '.tmp/app/css/',
                src: '*.css'
            }
        }
    });
    grunt.registerTask('build', [
        'clean:dist',//清除目录
//        'ngtemplates',//added by stone
        'ngAnnotate:app',
        'copy:styles',
        'copy:dist',
        'useminPrepare',
        'concat:generated',
//        'concat:ngtemplates',
        'cssmin',
        'uglify:generated',
        'filerev',
        'usemin',
        'htmlmin'
    ]);
    grunt.registerTask('default', ['build']);
};
